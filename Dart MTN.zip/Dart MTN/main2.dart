 
  void main(){ 
    String Name = "Ambani Africa";
    String Catergory = "Best Gaming Solution, Best Educational Solution, Best 'South African' App";
    String Developer = "Mukundi Lambani";
    String Year = "2021"; 
    
    print(Name.toUpperCase());
    print(Catergory.toUpperCase());
    print(Developer.toUpperCase());
    print(Year.toUpperCase());

  }
  



  
  

