

void main(){
  String Name = "Tasmiyah";
  String FApp = "Instagram";
  String City = "Pretoria";

  print("Name is $Name");
  print("Favourite App is $FApp");
  print("City is $City");

}
