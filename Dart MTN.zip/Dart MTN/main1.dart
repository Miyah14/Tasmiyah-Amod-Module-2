void main(){
  var listofWinners = [
    "2012 - FNB", 
    "2013 - SnapScan",
    "2014 - Live Inspect",
    "2015 - EskomSePush",
    "2016 - Domestly",
    "2017 - Shyft",
    "2018 - Khula Ecosystems",
    "2019 - Naked Insurance",
    "2020 - EasyEquities",
    "2021 - Ambani Africa"];

  print("List of MTN App of the year winners: $listofWinners");

  String Winner17 = "Shyft";
  String Winner18 = "Khula Ecosystems";
  print("The winner of the 2017 app of the year award is : $Winner17 ");
  print("The winner of the 2017 app of the year award is : $Winner18 ");

  int TotalNumofApps = 10;
  print("The total number of apps in the list is : $TotalNumofApps");

}
